import{a as t}from"../chunks/entry.pr5mgTOW.js";export{t as start};
