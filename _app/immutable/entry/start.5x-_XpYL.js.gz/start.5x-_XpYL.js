import{a as t}from"../chunks/entry.XAN73xLW.js";export{t as start};
