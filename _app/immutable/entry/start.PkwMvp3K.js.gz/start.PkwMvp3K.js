import{a as t}from"../chunks/entry.__TCLBIZ.js";export{t as start};
