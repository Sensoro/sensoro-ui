import{a as t}from"../chunks/entry.1oAEuBdF.js";export{t as start};
