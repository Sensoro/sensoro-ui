import{a as t}from"../chunks/entry.r40JtwHQ.js";export{t as start};
