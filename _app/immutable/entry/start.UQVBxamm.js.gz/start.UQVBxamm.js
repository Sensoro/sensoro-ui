import{a as t}from"../chunks/entry.3zFzgmvZ.js";export{t as start};
